package com.gdu.app01.xml01;

public class Student {
	
	// field
	private String stuNo;
	private String name;
	private Calculator calculator;
	
	// default constructor
	
	// method
	// getter + setter
	public String getStuNo() {
		return stuNo;
	}
	public void setStuNo(String stuNo) {
		this.stuNo = stuNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Calculator getCalculator() {
		return calculator;
	}
	public void setCalculator(Calculator calculator) {
		this.calculator = calculator;
	}
	

}
