package com.gdu.app01.xml02;

public class Contact {

	// field
	private String tel;
	private String fax;

	// default constructor
	
	// method(getter + setter)
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}

}