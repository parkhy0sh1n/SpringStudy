package com.gdu.app01.xml02;

public class Academy {

	// field
	private String name;
	private Address address;
	
	// default constructor
	
	// method(getter + setter)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	
}